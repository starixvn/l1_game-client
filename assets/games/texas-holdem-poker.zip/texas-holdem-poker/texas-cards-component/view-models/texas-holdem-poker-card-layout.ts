const { ccclass, property, executeInEditMode, menu } = cc._decorator;

@ccclass
@executeInEditMode
export default class TexasHoldemPokerCardLayout extends cc.Component {
  @property(cc.Node)
  content: cc.Node = null;

  @property(cc.Node)
  shadow: cc.Node = null;

  @property
  movingOffsetX = 0;

  @property
  _spacingX = 20;

  @property
  get spacingX() {
    return this._spacingX;
  }

  set spacingX(value) {
    this._spacingX = value;
    this.updateLayout();
  }

  @property
  _ratio = 0.9;

  @property
  get ratio() {
    return this._ratio;
  }

  set ratio(value) {
    this._ratio = value;
    this.updateLayout();
  }

  cardSizeWidth = 76;

  selectedPosY = 36;
  selectedPosZ = 60;
  public selectedRotationX = 20;
  _selected = undefined;
  shadowWidth = 100;

  onLoad() {
    if (CC_EDITOR) {
      this.content.on(cc.Node.EventType.CHILD_ADDED, this.updateLayout, this);
      this.content.on(cc.Node.EventType.CHILD_REMOVED, this.updateLayout, this);
      this.content.on(cc.Node.EventType.CHILD_REORDER, this.updateLayout, this);
      this.updateLayout();
    } else {
      this._selected = undefined;
      this.content.removeAllChildren();
      //}
    }
  }

  updateLayout() {
    let width = 0;
    const halfCardSize = this.cardSizeWidth / 2;
    this.content.children.forEach((child, index) => {
      child.zIndex = index;
      child.x = halfCardSize + this.ratio * index * this.spacingX;
      if (this._selected) {
        child.x += this.movingOffsetX;
      }
    });
    width = this.cardSizeWidth + this.ratio * (this.content.childrenCount - 1) * this.spacingX;
    this.content.width = width;
  }

  getNextPosition(forceRenderPosition?: number): cc.Vec3 {
    const position = forceRenderPosition == undefined ? this.content.childrenCount : forceRenderPosition;

    let x = this.cardSizeWidth / 2 + this.ratio * position * this.spacingX;
    let y = 0;
    let z = 0;

    if (this._selected) {
      x += this.movingOffsetX;
      y = this.selectedPosY;
      z = this.selectedPosZ;
    }

    return cc.v3(x, y, z);
  }

  changeCardView(selected: boolean) {
    this._selected = selected;
    if (selected) {
      this.content.children.forEach((child, index) => {
        child.is3DNode = true;
        cc.tween(child)
          .delay(0.1 * (this.content.childrenCount - 1 - index))
          .parallel(
            cc.tween(child).by(0.3, { x: this.movingOffsetX }),
            cc
              .tween(child)
              .to(
                0.3,
                { eulerAngles: cc.v3(this.selectedRotationX), y: this.selectedPosY - 46, z: this.selectedPosZ },
                { easing: "sineIn" }
              )
          )
          .start();
      });
      this.shadow.active = true;
    } else {
      this.content.children.forEach((child, index) => {
        child.is3DNode = true;
        const isLastChild = index === this.content.childrenCount - 1;
        cc.tween(child)
          .delay(0.1 * index)
          .parallel(
            cc.tween(child).by(0.3, { x: -this.movingOffsetX }),
            cc.tween(child).to(0.3, { eulerAngles: cc.v3(0, 0, 0), y: 0, z: 0 })
          )
          .call(() => {
            if (isLastChild) {
              this.updateLayout();
            }
          })
          .start();
      });
    }
  }
}
