import { HoldemPokerGameData } from "../../holdem-poker/event-models/HoldemPokerGameData";
import TexasHoldemErrorUIEventHandler from "../event-handlers/texas-holdem-poker-api-error-ui-handler";
import TexasHoldemAutoSettleEventHandler from "../event-handlers/texas-holdem-poker-auto-settle-handler";
import TexasHoldemCallEventHandler from "../event-handlers/texas-holdem-poker-call-handler";
import TexasHoldemPokerConfigsHandler from "../event-handlers/texas-holdem-poker-configs-handler";
import TexasHoldemDealEventHandler from "../event-handlers/texas-holdem-poker-deal-handler";
import TexasHoldemPokerFinishHandler from "../event-handlers/texas-holdem-poker-finish-handler";
import TexasHoldemPokerOwnBetHandler from "../event-handlers/texas-holdem-poker-own-bet-handler";
import TexasHoldemRiverEventHandler from "../event-handlers/texas-holdem-poker-river-handler";
import TexasTicketDetailEventHandler from "../event-handlers/texas-holdem-poker-ticket-detail-handler";
import TexasHoldemTurnEventHandler from "../event-handlers/texas-holdem-poker-turn-handler";
import { TexasHoldemPokerAutoSettleModel } from "./texas-holdem-poker-auto-settle-model";
import { TexasHoldemPokerAfterCallModel } from "./texas-holdem-poker-call-model";
import { TexasHoldemPokerChoicesConst } from "./texas-holdem-poker-choices";
import { TexasHoldemPokerConfigs } from "./texas-holdem-poker-configs";
import { TexasHoldemPokerAfterDealModel } from "./texas-holdem-poker-deal-model";
import { TexasHoldemPokerFinishModel } from "./texas-holdem-poker-finish-model";
import { TexasHoldemPokerOwnBetModel } from "./texas-holdem-poker-own-bet-model";
import { TexasHoldemPokerPlaceBetModel } from "./texas-holdem-poker-place-bet-model";
import { TexasHoldemPokerAfterRiverModel } from "./texas-holdem-poker-river-model";
import { TexasHoldemPokerSettlement } from "./texas-holdem-poker-settlement";
import { TexasHoldemPokerStateModel } from "./texas-holdem-poker-state-model";
import { TexasHoldemPokerTicketDetailModel } from "./texas-holdem-poker-ticket-detail-model";
import { TexasHoldemPokerAfterTurnModel } from "./texas-holdem-poker-turn-model";

export class TexasHoldemPokerGameData<Choices> extends HoldemPokerGameData<Choices> {
    readonly configs: TexasHoldemPokerConfigs;
    readonly placeBetModel: TexasHoldemPokerPlaceBetModel;
    readonly stateModel: TexasHoldemPokerStateModel;
    readonly dealModel: TexasHoldemPokerAfterDealModel;
    readonly ownBets: TexasHoldemPokerOwnBetModel;
    readonly finishModel: TexasHoldemPokerFinishModel;
    readonly settlement: TexasHoldemPokerSettlement;
    readonly ticketDetailModel: TexasHoldemPokerTicketDetailModel;

    readonly callModel: TexasHoldemPokerAfterCallModel;
    readonly turnModel: TexasHoldemPokerAfterTurnModel;
    readonly riverModel: TexasHoldemPokerAfterRiverModel;
    readonly autoSettleModel: TexasHoldemPokerAutoSettleModel;

    constructor() {
        super();

        this.configs = new TexasHoldemPokerConfigs();
        this.placeBetModel = new TexasHoldemPokerPlaceBetModel();
        this.stateModel = new TexasHoldemPokerStateModel();
        this.settlement = new TexasHoldemPokerSettlement();
        this.autoSettleModel = new TexasHoldemPokerAutoSettleModel();

        this.dealModel = new TexasHoldemPokerAfterDealModel();
        this.callModel = new TexasHoldemPokerAfterCallModel();
        this.turnModel = new TexasHoldemPokerAfterTurnModel();
        this.riverModel = new TexasHoldemPokerAfterRiverModel();
        this.ownBets = new TexasHoldemPokerOwnBetModel();
        this.finishModel = new TexasHoldemPokerFinishModel();
        this.ticketDetailModel = new TexasHoldemPokerTicketDetailModel();
    }

    // Override isProcessingBet
    set isProcessingBet(value: boolean) {
        this.processingBetFlag = value;
        if (!this.processingBetFlag) {
            this.emit(TexasHoldemPokerGameData.Events.HIDE_PROCESSING_BET);
        }
    }

    get isProcessingBet() {
        return this.processingBetFlag;
    }

    receiveData(data: unknown) {
        if (!this.eventHandlers.length) {
            this.registerEventHandlers();
        }

        this.eventHandlers.forEach((handler) => handler.onReceiveEvent(data));
    }

    protected registerEventHandlers() {
        super.registerEventHandlers();
        const handlers = [
            TexasHoldemPokerConfigsHandler,
            TexasHoldemErrorUIEventHandler,
            TexasHoldemAutoSettleEventHandler,
            TexasHoldemDealEventHandler,
            TexasHoldemCallEventHandler,
            TexasHoldemTurnEventHandler,
            TexasHoldemRiverEventHandler,
            TexasHoldemPokerOwnBetHandler,
            TexasHoldemPokerFinishHandler,
            TexasTicketDetailEventHandler
        ];

        this.eventHandlers.push(...handlers.map((Handler) => new Handler(this)));
    }
    receiveUIData(data: any) {
        if (!!data.bet) {
            this.placeBetModel.placeBet(data.bet.choice, data.bet.amount);
            this.stateModel.placeBet(data.bet.choice, this.placeBetModel);
        }
        if (!!data.deal) {
            this.stateModel.deal();
        }
        if (!!data.double) {
            this.placeBetModel.double(data.double.choice);
        }
        if (!!data.cancel) {
            this.placeBetModel.resetBets();
            this.stateModel.cancelBet();
        }

        if (!!data.doubleCall) {
            this.placeBetModel.doubleAndCall();
            this.stateModel.call();
        }
        if (!!data.betTurn) {
            this.placeBetModel.updateBetModel(TexasHoldemPokerChoicesConst.turnBet, TexasHoldemPokerPlaceBetModel.Events.TURN);
            this.stateModel.turning();
        }
        if (!!data.checkTurn) {
            this.stateModel.checkTurn();
        }
        if (!!data.betRiver) {
            this.placeBetModel.updateBetModel(TexasHoldemPokerChoicesConst.riverBet, TexasHoldemPokerPlaceBetModel.Events.RIVER);
            this.stateModel.rivering();
        }
        if (!!data.checkRiver) {
            this.stateModel.checkRiver();
        }
        if (!!data.rebet) {
            this.placeBetModel.rebet();
            this.stateModel.rebet();
        }
        if (!!data.rebetAndDeal) {
            this.placeBetModel.rebetAndDeal();
            this.stateModel.deal();
        }
        if (!!data.new) {
            this.placeBetModel.new();
            this.stateModel.resetState();
        }
        if (!!data.replayNew) {
            this.placeBetModel.replayNew();
            this.stateModel.replayNew();
        }
        if (!!data.fold) {
            this.stateModel.fold();
        }
    }
}
